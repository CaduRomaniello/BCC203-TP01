function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [31, 7, 23, 25, 14, 17, 45, 49, 2, 14,
      30, 32, 19, 58, 61, 62, 53, 52, 20, 44,
      80, 168, 148, 153, 100, 211, 48, 184, 47, 26,
      1642, 1078, 261, 331, 1477, 894, 1213, 2007, 967, 1543,
      14962, 9319, 9989, 6487, 18270, 4748, 4145, 15850, 18764, 19335,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [417, 393, 409, 411, 400, 403, 431, 435, 388, 400,
      7026, 7028, 7015, 7054, 7057, 7058, 7049, 7048, 7016, 7040,
      103724, 103812, 103792, 103797, 103744, 103855, 103692, 103828, 103691, 103670,
      1370604, 1370040, 1369223, 1369293, 1370439, 1369856, 1370175, 1370969, 1369929, 1370505,
      16966426, 16960783, 16961453, 16957951, 16969734, 16956212, 16955609, 16967314, 16970228, 16970799,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box',
};

var trace3 = {
  y: [610, 586, 602, 604, 593, 596, 624, 628, 581, 593,
      6915, 6917, 6904, 6943, 6946, 6947, 6938, 6937, 6905, 6929,
      108177, 108265, 108245, 108250, 108197, 108308, 108145, 108281, 108144, 108123,
      1314189, 1313625, 1312808, 1312878, 1314024, 1313441, 1313760, 1314554, 1313514, 1314090,
      16019261, 16013618, 16014288, 16010786, 16022569, 16009047, 16008444, 16020149, 16023063, 16023634,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'ASI Comparações Totais',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);