function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [31, 7, 23, 25, 14, 17, 45, 49, 2, 14,
      30, 32, 19, 58, 61, 62, 53, 52, 20, 44,
      80, 168, 148, 153, 100, 211, 48, 184, 47, 26,
      1642, 1078, 261, 331, 1477, 894, 1213, 2007, 967, 1543,
      14962, 9319, 9989, 6487, 18270, 4748, 4145, 15850, 18764, 19335,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [31, 7, 23, 25, 14, 17, 45, 49, 2, 14,
      30, 32, 19, 58, 61, 62, 53, 52, 20, 44,
      80, 168, 148, 153, 100, 211, 48, 184, 47, 26,
      1642, 1078, 261, 331, 1477, 894, 1213, 2007, 967, 1543,
      14962, 9319, 9989, 6487, 18270, 4748, 4145, 15850, 18764, 19335,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box'
};

var trace3 = {
  y: [31, 7, 23, 25, 14, 17, 45, 49, 2, 14,
      30, 32, 19, 58, 61, 62, 53, 52, 20, 44,
      80, 168, 148, 153, 100, 211, 48, 184, 47, 26,
      1642, 1078, 261, 331, 1477, 894, 1213, 2007, 967, 1543,
      14962, 9319, 9989, 6487, 18270, 4748, 4145, 15850, 18764, 19335,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'ASI Comparações Pesquisa',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);