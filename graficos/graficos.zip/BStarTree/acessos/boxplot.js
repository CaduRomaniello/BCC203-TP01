function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [78, 78, 78, 78, 78, 78, 78, 78, 78, 78,
      760, 760, 760, 760, 760, 760, 760, 760, 760, 760,
      7512, 7512, 7512, 7512, 7512, 7512, 7512, 7512, 7512, 7512,
      75014, 75014, 75014, 75014, 75014, 75014, 75014, 75014, 75014, 75014,
      750017, 750017, 750017, 750017, 750017, 750017, 750017, 750017, 750017, 750017,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [55, 55, 55, 55, 55, 55, 55, 55, 55, 55,
      509, 509, 509, 509, 509, 509, 509, 509, 509, 509,
      5011, 5011, 5011, 5011, 5011, 5011, 5011, 5011, 5011, 5011,
      50014, 50014, 50014, 50014, 50014, 50014, 50014, 50014, 50014, 50014,
      500016, 500016, 500016, 500016, 500016, 500016, 500016, 500016, 500016, 500016,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box',
};

var trace3 = {
  y: [56 + 100, 56 + 100, 56 + 100, 56 + 100, 56 + 100, 56 + 100, 56 + 100, 56 + 100, 56 + 100, 56 + 100,
      488 + 1000, 488 + 1000, 488 + 1000, 488 + 1000, 488 + 1000, 488 + 1000, 488 + 1000, 488 + 1000, 488 + 1000, 488 + 1000,
      4693 + 10000, 4693 + 10000, 4693 + 10000, 4693 + 10000, 4693 + 10000, 4693 + 10000, 4693 + 10000, 4693 + 10000, 4693 + 10000, 4693 + 10000,
      46930 + 100000, 46930 + 100000, 46930 + 100000, 46930 + 100000, 46930 + 100000, 46930 + 100000, 46930 + 100000, 46930 + 100000, 46930 + 100000, 46930 + 100000,
      468584 + 1000000, 468584 + 1000000, 468584 + 1000000, 468584 + 1000000, 468584 + 1000000, 468584 + 1000000, 468584 + 1000000, 468584 + 1000000, 468584 + 1000000, 468584 + 1000000,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BStarTree Acessos',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);