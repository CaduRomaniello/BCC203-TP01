function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [1270, 1270, 1270, 1270, 1270, 1270, 1270, 1270, 1270, 1270,
      19220, 19220, 19220, 19220, 19220, 19220, 19220, 19220, 19220, 19220,
      254528, 254528, 254528, 254528, 254528, 254528, 254528, 254528, 254528, 254528,
      3169982, 3169982, 3169982, 3169982, 3169982, 3169982, 3169982, 3169982, 3169982, 3169982,
      38004207, 38004207, 38004207, 38004207, 38004207, 38004207, 38004207, 38004207, 38004207, 38004207,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [472, 472, 472, 472, 472, 472, 472, 472, 472, 472,
      7059, 7059, 7059, 7059, 7059, 7059, 7059, 7059, 7059, 7059,
      91704, 91704, 91704, 91704, 91704, 91704, 91704, 91704, 91704, 91704,
      1124199, 1124199, 1124199, 1124199, 1124199, 1124199, 1124199, 1124199, 1124199, 1124199,
      13301785, 13301785, 13301785, 13301785, 13301785, 13301785, 13301785, 13301785, 13301785, 13301785,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box'
};

var trace3 = {
  y: [928, 928, 928, 928, 928, 928, 928, 928, 928, 928,
      13317, 13317, 13317, 13317, 13317, 13317, 13317, 13317, 13317, 13317,
      171973, 171973, 171973, 171973, 171973, 171973, 171973, 171973, 171973, 171973,
      2095148, 2095148, 2095148, 2095148, 2095148, 2095148, 2095148, 2095148, 2095148, 2095148,
      24779811, 24779811, 24779811, 24779811, 24779811, 24779811, 24779811, 24779811, 24779811, 24779811,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BStarTree Comparações Criação',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);