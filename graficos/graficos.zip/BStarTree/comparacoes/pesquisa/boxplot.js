function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [4, 10, 5, 12, 8, 8, 6, 6, 6, 8,
      10, 10, 9, 10, 8, 11, 13, 12, 10, 11,
      14, 12, 16, 13, 13, 13, 18, 15, 14, 23,
      15, 14, 19, 20, 16, 18, 16, 22, 17, 19,
      23, 17, 22, 21, 20, 22, 23, 23, 24, 20,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [6, 9, 10, 8, 5, 9, 4, 8, 5, 9,
      10, 11, 12, 13, 10, 10, 14, 12, 12, 9,
      15, 14, 14, 15, 16, 16, 14, 14, 13, 18,
      14, 16, 19, 18, 15, 18, 18, 20, 16, 17,
      20, 18, 21, 22, 22, 23, 21, 23, 23, 22,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box'
};

var trace3 = {
  y: [6, 9, 8, 7, 9, 9, 4, 10, 8, 7,
      9, 12, 13, 12, 8, 11, 11, 13, 9, 12,
      15, 16, 16, 13, 11, 17, 19, 12, 15, 19,
      16, 17, 20, 19, 15, 23, 19, 19, 17, 21,
      19, 17, 18, 26, 26, 22, 21, 27, 21, 24,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BStarTree Comparações Pesquisa',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);