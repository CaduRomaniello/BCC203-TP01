function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [1274, 1280, 1275, 1282, 1278, 1278, 1276, 1276, 1276, 1278,
      19230, 19230, 19229, 19230, 19228, 19231, 19233, 19232, 19230, 19231,
      254542, 254540, 254544, 254541, 254541, 254541, 254546, 254543, 254542, 254551,
      3169997, 3169996, 3170001, 3170002, 3169998, 3170000, 3169998, 3170004, 3169999, 3170001,
      38004230, 38004224, 38004229, 38004228, 38004227, 38004229, 38004230, 38004230, 38004231, 38004227,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [478, 481, 482, 480, 477, 481, 476, 480, 477, 481,
      7069, 7070, 7071, 7072, 7069, 7069, 7073, 7071, 7071, 7068,
      91719, 91718, 91718, 91719, 91720, 91720, 91718, 91718, 91717, 91722,
      1124213, 1124215, 1124218, 1124217, 1124214, 1124217, 1124217, 1124219, 1124215, 1124216,
      13301805, 13301803, 13301806, 13301807, 13301807, 13301808, 13301806, 13301808, 13301808, 13301807,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box',
};

var trace3 = {
  y: [934, 937, 936, 935, 937, 937, 932, 938, 936, 935,
      13326, 13329, 13330, 13329, 13325, 13328, 13328, 13330, 13326, 13329,
      171988, 171989, 171989, 171986, 171984, 171990, 171992, 171985, 171988, 171992,
      2095164, 2095165, 2095168, 2095167, 2095163, 2095171, 2095167, 2095167, 2095165, 2095169,
      24779830, 24779828, 24779829, 24779837, 24779837, 24779833, 24779832, 24779838, 24779832, 24779835,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BStarTree Comaparções Totais',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);