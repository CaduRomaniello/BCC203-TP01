function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [55, 55, 55, 55, 55, 55, 55, 51, 53, 55,
      509, 509, 509, 509, 509, 509, 509, 509, 507, 509,
      5011, 5011, 5011, 5011, 5011, 5009, 5009, 5009, 5011, 5011,
      50012, 50012, 50014, 50014, 50014, 50012, 50014, 50014, 50014, 50012,
      500016, 500016, 500016, 500014, 500016, 500016, 500014, 500014, 500016, 500016,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [55, 55, 49, 53, 55, 55, 55, 55, 55, 53,
      509, 507, 509, 509, 509, 509, 507, 509, 509, 509,
      5011, 5011, 5005, 5011, 5011, 5011, 5011, 5011, 5011, 5009,
      50014, 50014, 50012, 50012, 50014, 50014, 50012, 50014, 50012, 50014,
      500016, 500012, 500010, 500016, 500014, 500012, 500016, 500016, 500014, 500014,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box',
};

var trace3 = {
  y: [46 + 100, 44 + 100, 46 + 100, 44 + 100, 46 + 100, 44 + 100, 44 + 100, 44 + 100, 46 + 100, 46 + 100,
      387 + 1000, 387 + 1000, 387 + 1000, 385 + 1000, 387 + 1000, 387 + 1000, 387 + 1000, 387 + 1000, 387 + 1000, 387 + 1000,
      3685 + 10000, 3683 + 10000, 3685 + 10000, 3681 + 10000, 3683 + 10000, 3685 + 10000, 3685 + 10000, 3685 + 10000, 3685 + 10000, 3685 + 10000,
      36977 + 100000, 36977 + 100000, 36975 + 100000, 36977 + 100000, 36977 + 100000, 36975 + 100000, 36977 + 100000, 36977 + 100000, 36975 + 100000, 36975 + 100000,
      369090 + 1000000, 369092 + 1000000, 369090 + 1000000, 369092 + 1000000, 369092 + 1000000, 369092 + 1000000, 369092 + 1000000, 369092 + 1000000, 369088 + 1000000, 369092 + 1000000,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BTree Acessos',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);