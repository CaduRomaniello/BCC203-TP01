function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [3, 3, 3, 3, 3, 3, 3, 1, 2, 3,
      5, 5, 5, 5, 5, 5, 5, 5, 4, 5,
      7, 7, 7, 7, 7, 6, 6, 6, 7, 7,
      8, 8, 9, 9, 9, 8, 9, 9, 9, 8,
      11, 11, 11, 10, 11, 11, 10, 10, 11, 11,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [3, 3, 0, 2, 3, 3, 3, 3, 3, 2,
      5, 4, 5, 5, 5, 5, 4, 5, 5, 5,
      7, 7, 4, 7, 7, 7, 7, 7, 7, 6,
      9, 9, 8, 8, 9, 9, 8, 9, 8, 9,
      11, 9, 8, 11, 10, 9, 11, 11, 10, 10,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box'
};

var trace3 = {
  y: [3, 2, 3, 2, 3, 2, 2, 2, 3, 3,
      5, 5, 5, 4, 5, 5, 5, 5, 5, 5,
      6, 5, 6, 4, 5, 6, 6, 6, 6, 6,
      8, 8, 7, 8, 8, 7, 8, 8, 7, 7,
      9, 10, 9, 10, 10, 10, 10, 10, 8, 10,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BTree Fseek Pesquisa',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);