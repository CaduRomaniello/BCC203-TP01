function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [48, 48, 48, 48, 48, 48, 48, 48, 48, 48,
      498, 498, 498, 498, 498, 498, 498, 498, 498, 498,
      4996, 4996, 4996, 4996, 4996, 4996, 4996, 4996, 4996, 4996,
      49995, 49995, 49995, 49995, 49995, 49995, 49995, 49995, 49995, 49995,
      499993, 499993, 499993, 499993, 499993, 499993, 499993, 499993, 499993, 499993,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [48, 48, 48, 48, 48, 48, 48, 48, 48, 48,
      498, 498, 498, 498, 498, 498, 498, 498, 498, 498,
      4996, 4996, 4996, 4996, 4996, 4996, 4996, 4996, 4996, 4996,
      49995, 49995, 49995, 49995, 49995, 49995, 49995, 49995, 49995, 49995,
      499993, 499993, 499993, 499993, 499993, 499993, 499993, 499993, 499993, 499993,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box'
};

var trace3 = {
  y: [39, 39, 39, 39, 39, 39, 39, 39, 39, 39,
      376, 376, 376, 376, 376, 376, 376, 376, 376, 376,
      3672, 3672, 3672, 3672, 3672, 3672, 3672, 3672, 3672, 3672,
      36960, 36960, 36960, 36960, 36960, 36960, 36960, 36960, 36960, 36960,
      369071, 369071, 369071, 369071, 369071, 369071, 369071, 369071, 369071, 369071,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BTree Fwrite Criação',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);