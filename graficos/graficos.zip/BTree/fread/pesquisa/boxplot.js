function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [4, 4, 4, 4, 4, 4, 4, 2, 3, 4,
      6, 6, 6, 6, 6, 6, 6, 6, 5, 6,
      8, 8, 8, 8, 8, 7, 7, 7, 8, 8,
      9, 9, 10, 10, 10, 9, 10, 10, 10, 9,
      12, 12, 12, 11, 12, 12, 11, 11, 12, 12,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [4, 4, 1, 3, 4, 4, 4, 4, 4, 3,
      6, 5, 6, 6, 6, 6, 5, 6, 6, 6,
      8, 8, 5, 8, 8, 8, 8, 8, 8, 7,
      10, 10, 9, 9, 10, 10, 9, 10, 9, 10,
      12, 10, 9, 12, 11, 10, 12, 12, 11, 11,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box'
};

var trace3 = {
  y: [4, 3, 4, 3, 4, 3, 3, 3, 4, 4,
      6, 6, 6, 5, 6, 6, 6, 6, 6, 6,
      7, 6, 7, 5, 6, 7, 7, 7, 7, 7,
      9, 9, 8, 9, 9, 8, 9, 9, 8, 8,
      10, 11, 10, 11, 11, 11, 11, 11, 9, 11,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BTree Fread Pesquisa',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);