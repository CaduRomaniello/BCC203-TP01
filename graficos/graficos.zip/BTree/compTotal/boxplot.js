function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [1335, 1334, 1336, 1339, 1333, 1336, 1336, 1330, 1336, 1336,
      21579, 21581, 21582, 21579, 21582, 21580, 21584, 21582, 21577, 21581,
      299034, 299036, 299035, 299035, 299036, 299033, 299033, 299032, 299033, 299033,
      3832680, 3832679, 3832688, 3832688, 3832687, 3832685, 3832687, 3832684, 3832687, 3832685,
      46710256, 46710254, 46710255, 46710252, 46710253, 46710252, 46710247, 46710252, 46710255, 46710255,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [1070, 1068, 1059, 1066, 1065, 1069, 1068, 1069, 1068, 1065,
      15014, 15010, 15016, 15014, 15015, 15013, 15013, 15015, 15013, 15013,
      191836, 191834, 191827, 191836, 191835, 191834, 191835, 191835, 191836, 191833,
      2331848, 2331849, 2331851, 2331849, 2331849, 2331851, 2331848, 2331850, 2331845, 2331848,
      27437051, 27437044, 27437043, 27437052, 27437045, 27437046, 27437047, 27437050, 27437047, 27437050,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box',
};

var trace3 = {
  y: [1170, 1163, 1171, 1167, 1165, 1166, 1165, 1165, 1169, 1168,
      17266, 17267, 17268, 17264, 17266, 17272, 17270, 17272, 17267, 17266,
      226882, 226879, 226885, 226879, 226880, 226885, 226886, 226884, 226887, 226886,
      2831435, 2831438, 2831435, 2831441, 2831438, 2831433, 2831441, 2831439, 2831437, 2831438,
      33865206, 33865201, 33865204, 33865207, 33865204, 33865200, 33865204, 33865206, 33865200, 33865208,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BTree Comparações Totais',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);