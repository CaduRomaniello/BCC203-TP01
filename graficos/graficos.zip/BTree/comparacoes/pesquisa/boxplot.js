function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [9, 8, 10, 13, 7, 10, 10, 4, 10, 10,
      13, 15, 16, 13, 16, 14, 18, 16, 11, 15,
      20, 22, 21, 21, 22, 19, 19, 18, 19, 19,
      21, 20, 29, 29, 28, 26, 28, 25, 28, 26,
      35, 33, 34, 31, 32, 31, 26, 31, 34, 34,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [12, 10, 1, 8, 7, 11, 10, 11, 10, 7,
      15, 11, 17, 15, 16, 14, 14, 16, 14, 14,
      22, 20, 13, 22, 21, 20, 21, 21, 22, 19,
      25, 26, 28, 26, 26, 28, 25, 27, 22, 25,
      32, 25, 24, 33, 26, 27, 28, 31, 28, 31,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box'
};

var trace3 = {
  y: [12, 5, 13, 9, 7, 8, 7, 7, 11, 10,
      14, 15, 16, 12, 14, 20, 18, 20, 15, 14,
      18, 15, 21, 15, 16, 21, 22, 20, 23, 22,
      22, 25, 22, 28, 25, 20, 28, 26, 24, 25,
      34, 29, 32, 35, 32, 28, 32, 34, 28, 36,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BTree Comparações Pesquisa',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);