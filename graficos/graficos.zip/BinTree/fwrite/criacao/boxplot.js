function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
      1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000,
      10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000,
      100000, 100000, 100000, 100000, 100000, 100000, 100000, 100000, 100000, 100000,
      1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
      1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000,
      10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000,
      100000, 100000, 100000, 100000, 100000, 100000, 100000, 100000, 100000, 100000,
      1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box'
};

var trace3 = {
  y: [100, 100, 100, 100, 100, 100, 100, 100, 100, 100,
      1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000,
      10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000,
      100000, 100000, 100000, 100000, 100000, 100000, 100000, 100000, 100000, 100000,
      1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000, 1000000,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BinTree Fwrite Criação',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);