function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [2, 5, 6, 4, 4, 6, 6, 5, 5, 5,
      8, 9, 8, 8, 5, 8, 8, 8, 9, 5,
      12, 12, 10, 11, 11, 10, 11, 12, 12, 12,
      15, 15, 14, 15, 15, 15, 11, 15, 16, 14,
      19, 17, 19, 17, 19, 11, 16, 18, 19, 17,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [6, 4, 3, 6, 6, 4, 4, 5, 5, 3,
      9, 7, 9, 9, 9, 9, 9, 9, 8, 9,
      12, 13, 14, 13, 14, 13, 13, 13, 11, 9,
      16, 16, 17, 16, 14, 16, 17, 15, 15, 17,
      17, 19, 15, 19, 18, 19, 19, 18, 16, 19,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box'
};

var trace3 = {
  y: [5, 5, 5, 5, 6, 6, 6, 5, 6, 3,
      8, 9, 9, 9, 8, 10, 9, 8, 7, 8,
      13, 13, 11, 13, 10, 12, 9, 11, 14, 9,
      13, 13, 15, 16, 14, 15, 16, 9, 16, 16,
      17, 19, 15, 19, 18, 19, 19, 18, 16, 19,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BinTree Fseek Pesquisa',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);