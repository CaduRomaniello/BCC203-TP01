function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [676, 679, 680, 678, 678, 680, 680, 679, 679, 679,
      9986, 9987, 9986, 9986, 9983, 9986, 9986, 9986, 9987, 9983,
      133630, 133630, 133628, 133629, 133629, 133628, 133629, 133630, 133630, 133630,
      1668945, 1668945, 1668944, 1668945, 1668945, 1668945, 1668941, 1668945, 1668946, 1668944,
      19951445, 19951443, 19951445, 19951443, 19951445, 19951437, 19951442, 19951444, 19951445, 19951443,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [680, 678, 677, 680, 680, 678, 678, 679, 679, 677,
      9987, 9985, 9987, 9987, 9987, 9987, 9987, 9987, 9986, 9987,
      133629, 133630, 133631, 133630, 133631, 133630, 133630, 133630, 133628, 133626,
      1668945, 1668945, 1668946, 1668945, 1668943, 1668945, 1668946, 1668944, 1668944, 1668946,
      19951443, 19951445, 19951441, 19951445, 19951444, 19951445, 19951445, 19951444, 19951442, 19951445,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box',
};

var trace3 = {
  y: [645, 645, 645, 645, 646, 646, 646, 645, 646, 643,
      9705, 9706, 9706, 9706, 9705, 9707, 9706, 9705, 9704, 9705,
      130839, 130839, 130837, 130839, 130836, 130838, 130835, 130837, 130840, 130835,
      1651546, 1651546, 1651548, 1651549, 1651547, 1651548, 1651549, 1651542, 1651549, 1651549,
      19854908, 19854910, 19854906, 19854910, 19854909, 19854910, 19854910, 19854909, 19854907, 19854910,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BinTree Comparações Totais',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);