function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100', 'Qntd: 100',
         'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K', 'Qntd: 1K',
         'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K', 'Qntd: 10K',
         'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K', 'Qntd: 100K',
         'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M', 'Qntd: 1M',
        ]

var trace1 = {
  y: [105, 111, 113, 109, 109, 113, 113, 111, 111, 111,
      1017, 1019, 1017, 1017, 1011, 1017, 1017, 1017, 1019, 1011,
      10025, 10025, 10021, 10023, 10023, 10021, 10023, 10025, 10025, 10025,
      100031, 100031, 100029, 100031, 100031, 100031, 100023, 100031, 100033, 100029,
      1000039, 1000035, 1000039, 1000035, 1000039, 1000023, 1000033, 1000037, 1000039, 1000035,
     ],
  x: x,
  name: 'Crescente',
  marker: {color: boxColor[0]},
  type: 'box'
};

var trace2 = {
  y: [113, 109, 107, 113, 113, 109, 109, 111, 111, 107,
      1019, 1015, 1019, 1019, 1019, 1019, 1019, 1019, 1017, 1019,
      10023, 10025, 10027, 10025, 10027, 10025, 10025, 10025, 10021, 10017,
      100031, 100031, 100033, 100031, 100027, 100031, 100033, 100029, 100029, 100033,
      1000035, 1000039, 1000031, 1000039, 1000037, 1000039, 1000039, 1000037, 1000033, 1000039,
     ],
  x: x,
  name: 'Decrescente',
  marker: {color: boxColor[9]},
  type: 'box',
};

var trace3 = {
  y: [111 + 100, 111 + 100, 111 + 100, 111 + 100, 113 + 100, 113 + 100, 113 + 100, 111 + 100, 113 + 100, 107 + 100,
      1017 + 1000, 1019 + 1000, 1019 + 1000, 1019 + 1000, 1017 + 1000, 1021 + 1000, 1019 + 1000, 1017 + 1000, 1015 + 1000, 1017 + 1000,
      10027 + 10000, 10027 + 10000, 10023 + 10000, 10027 + 10000, 10021 + 10000, 10025 + 10000, 10019 + 10000, 10023 + 10000, 10029 + 10000, 10019 + 10000,
      100027 + 100000, 100027 + 100000, 100031 + 100000, 100033 + 100000, 100029 + 100000, 100031 + 100000, 100033 + 100000, 100019 + 100000, 100033 + 100000, 100033 + 100000,
      1000035 + 1000000, 1000039 + 1000000, 1000031 + 1000000, 1000039 + 1000000, 1000037 + 1000000, 1000039 + 1000000, 1000039 + 1000000, 1000037 + 1000000, 1000033 + 1000000, 1000039 + 1000000,
     ],
  x: x,
  name: 'Aleatório',
  marker: {color: boxColor[15]},
  type: 'box'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'BinTree Acessos',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);