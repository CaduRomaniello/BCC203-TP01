function linspace(a, b, n) {
    return Plotly.d3.range(n).map(function (i) { return a + i * (b - a) / (n - 1); });
}

var boxNumber = 30;
var boxColor = [];
var allColors = linspace(0, 360, boxNumber);
var data = [];

//Colors
for (var i = 0; i < boxNumber; i++) {
    var result = 'hsl(' + allColors[i] + ',50%' + ',50%)';
    boxColor.push(result);
}

// console.log(boxColor)

function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
};

var x = ['ASI', 'BIN', 'B', 'B*']

var trace1 = {
  y: [2390923.93333, 4345121.6, 7852223.866, 5535706.866666],
  x: x,
  name: 'Criação',
  marker: {color: boxColor[0]},
  type: 'bar'
};

var trace2 = {
  y: [2702.1, 12.36, 20.006666666666668, 14.58],
  x: x,
  name: 'Pesquisa',
  marker: {color: boxColor[9]},
  type: 'bar',
};

var trace3 = {
  y: [2393626.0333, 4345133.96, 7852243.87333333, 5535721.4466666],
  x: x,
  name: 'Total',
  marker: {color: boxColor[15]},
  type: 'bar'
};

var data = [trace1, trace2, trace3];

var layout = {
  yaxis: {
    title: 'Media Comparacoes',
    zeroline: false
  },
  boxmode: 'group'
};

Plotly.newPlot('myDiv', data, layout);